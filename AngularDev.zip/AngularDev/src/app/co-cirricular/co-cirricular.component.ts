import { Component } from '@angular/core';

@Component({
  selector: 'app-co-cirricular',
  templateUrl: './co-cirricular.component.html',
  styleUrls: ['./co-cirricular.component.scss']
})
export class CoCirricularComponent {

}
