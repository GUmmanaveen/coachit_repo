import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoCirricularComponent } from './co-cirricular.component';

describe('CoCirricularComponent', () => {
  let component: CoCirricularComponent;
  let fixture: ComponentFixture<CoCirricularComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoCirricularComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CoCirricularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
