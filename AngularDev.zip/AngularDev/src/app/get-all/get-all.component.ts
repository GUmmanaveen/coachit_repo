import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { DataService, StudentData } from '../data.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-get-all',
  templateUrl: './get-all.component.html',
  styleUrls: ['./get-all.component.scss']
})
export class GetAllComponent {
  // dataSource !:MatTableDataSource<StudentData>;
  // dataSource1 !:StudentData
  studentsData = new Array<StudentData>
  // studentsData !:MatTableDataSource>
  displayedColumns = ['campusType', 'companyType', 'employer', 'package', 'offerNumber', 'studentRollNumber']
  // length=10;
  // pageSize=3;
  // pageIndex=0;
  // pageSizeOptions=[1,3,5];
  // showFirstLastButtons=true;
  constructor(public dService: DataService) {

  }

  ngOnInit() {
    debugger
    this.dService.getPlacementData().subscribe((response) => {
      debugger
      console.log(response)

      this.studentsData = response
      console.log(this.studentsData)
    },
      (error) => {
        debugger
        console.log(error.error.response)
      }
    )
    //  debugger
    //  console.log('abc')
    //     this.dataSource= new MatTableDataSource([this.dataSource1])
    //     console.log(this.dataSource)
    //     console.log(12345)

  }
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  // ngAfterViewInit() {
  //   this.studentsData.paginator = this.paginator;
  // }
}
