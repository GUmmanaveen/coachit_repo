import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService, StudentData } from '../data.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Action } from 'rxjs/internal/scheduler/Action';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.scss']
})
export class DisplayComponent implements OnInit {
  selectedFile!: File | Blob;
  selectedFile1!: File | Blob;
  ngOnInit(): void {
  }
  constructor(public router: Router, public dService: DataService, public snackBar: MatSnackBar) { }
  selectFiles(event: any, type: string) {
    console.log((event.target.files).length);
    switch (type) {
      case 'OFFER':
        this.selectedFile = event.target.files[0];
        break;
      case 'INTENT':
        this.selectedFile1 = event.target.files[0];
        break;
      default:
        break;
    }
  }
  formData = new FormData();
  storeData(sData: StudentData, data: any) {
    let s = sData
    let s1 = sessionStorage.getItem('rollNo')
    if (s1 != null) {
      s.rollNo = s1
    }

    if (this.selectedFile) {
      this.formData = new FormData();
      this.formData.set('offer-letter', this.selectedFile)
      this.formData.append('letter-of-intent', this.selectedFile1)
      this.formData.append('student-roll-number', s.rollNo)
      this.formData.append('offer-number', (s.offerNumber).toString())
      this.formData.append('company-name', s.companyName)
      this.formData.append('package', (s.package).toString())
      this.formData.append('company-type', s.companyType)
      this.formData.append('campus-type', s.campusType)
    }

    data.form.reset();
    console.log(this.formData.getAll)
    this.dService.saveStudentData(this.formData)
    let message = 'successfully updated'
    // this.snackBar.open( message,{ duration: 5000,});
  }
  toHome() {
    this.router.navigate(["/''"])
  }
}


