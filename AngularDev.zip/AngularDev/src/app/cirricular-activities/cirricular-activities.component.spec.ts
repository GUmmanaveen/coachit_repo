import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CirricularActivitiesComponent } from './cirricular-activities.component';

describe('CirricularActivitiesComponent', () => {
  let component: CirricularActivitiesComponent;
  let fixture: ComponentFixture<CirricularActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CirricularActivitiesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CirricularActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
