import { Component } from '@angular/core';

@Component({
  selector: 'app-cirricular-activities',
  templateUrl: './cirricular-activities.component.html',
  styleUrls: ['./cirricular-activities.component.scss']
})
export class CirricularActivitiesComponent {

}
