import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class DataService {
  s = new StudentData
  l = new LoginObj
  constructor(private http: HttpClient) {

  }

  response: any
  public saveStudentData(studentsData: FormData): Observable<any> {
    const url = ' http://localhost:8085/student-placement-data';
    const headers = new HttpHeaders()
      //.set('content-type', 'multipart/form-data;')
      .set('Access-Control-Allow-Origin', '*');
    console.log(studentsData.getAll('offer-letter'));
    this.http.post<any>(url, studentsData, { 'headers': headers }).subscribe((response) => {
      console.log(response)
    },
      (error) => {
        console.log(error)
      })
    return this.response

  }
  getData(data: LoginObj): Observable<any> {
    let inputData = new URLSearchParams()
    inputData.set("username", data.username);
    inputData.set("password", data.password);
    console.log(inputData);
    const url = 'http://localhost:8085/login';
    const headers = new HttpHeaders()
      .set('Content-type', 'application/x-www-form-urlencoded')
      .set('Access-Control-Allow-Origin', '*');
    return this.http.post(url, inputData, { 'headers': headers })
    //  .subscribe((loginResponse)=>{
    //     debugger
    //     console.log(loginResponse)
    //     this.response = loginResponse
    //    },
    //    (error)=>{
    //     debugger
    //     console.log(error)
    //     this.response = error
    //    })
    // return this.http.post(url,inputData,{ 'headers': headers }).pipe(

    //   catchError((err) => {
    //     console.log('error caught in service')
    //     return err 
    //   })
    // )
    //return this.response


    //    const body = new URLSearchParams();
    //   body.set('page', '1');
    //   body.set('sort', 'name');
    //   let options = {
    //     headers: new HttpHeaders().set(
    //       'Content-Type',
    //       'application/x-www-form-urlencoded'
    //     )
    //   };
    //   this.http.post(this.url, body.toString(), options).subscribe(
    //     mock => {
    //       console.log('success', mock);
    //     },
    //     mockError => {
    //       console.log('error', mockError);
    //     }
    //   );
  }
  getPlacementData(): Observable<any> {
    debugger
    const url = 'http://localhost:8085/student-placement-data';
    return this.http.get<any>(url);
  }

}
export class StudentData {
  rollNo!: string
  offerNumber!: number
  companyName!: string
  package!: number
  companyType!: string
  campusType!: string
  // "login" :LoginObj |LoginObj
  // constructor(){
  //   login:new LoginObj()
  // }
}
export class LoginObj {
  username!: string
  password!: string;

}