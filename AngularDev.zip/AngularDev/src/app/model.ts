export class  login{
rollNumber!:String;
}
export class PlacementData{
    // "rollNo": string |undefined
	"offerNumber": number |undefined
	"companyName": string |undefined
	"package": number |undefined
	"companyType": string |undefined
	"campusType":string |undefined
}