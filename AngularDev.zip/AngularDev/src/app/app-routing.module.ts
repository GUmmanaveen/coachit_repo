import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DisplayComponent } from './display/display.component';
import { RegisterComponent } from './register/register.component';
import { HigherEduComponent } from './higher-edu/higher-edu.component';
import { QualifyingExamsComponent } from './qualifying-exams/qualifying-exams.component';
import { InternshipComponent } from './internship/internship.component';
import { CirricularActivitiesComponent } from './cirricular-activities/cirricular-activities.component';
import { CoCirricularComponent } from './co-cirricular/co-cirricular.component';
import { CertificationsComponent } from './certifications/certifications.component';
import { WorkshopsComponent } from './trainings/workshops/workshops.component';
import { ProjectsComponent } from './projects/projects.component';
import { HackathonsComponent } from './hackathons/hackathons.component';
import { GetAllComponent } from './get-all/get-all.component';

const routes: Routes = [
  { path: '', component: RegisterComponent },
  { path: 'display', component: DisplayComponent },
  { path: 'home', component: RegisterComponent },
  { path: 'higherEdu', component: HigherEduComponent },
  { path: 'qualifyingExam', component: QualifyingExamsComponent },
  { path: 'internship', component: InternshipComponent },
  { path: 'cirricular', component: CirricularActivitiesComponent },
  { path: 'co-cirricular', component: CoCirricularComponent },
  { path: 'home', component: RegisterComponent },
  { path: 'certifications', component: CertificationsComponent },
  { path: 'trainings', component: WorkshopsComponent },
  { path: 'projects', component: ProjectsComponent },
  { path: 'hackathons', component: HackathonsComponent },
  { path: 'table', component: GetAllComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
