import { Component } from '@angular/core';

@Component({
  selector: 'app-higher-edu',
  templateUrl: './higher-edu.component.html',
  styleUrls: ['./higher-edu.component.scss']
})
export class HigherEduComponent {

}
