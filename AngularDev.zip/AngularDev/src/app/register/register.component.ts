import { Component, OnInit } from '@angular/core';
import { DataService, LoginObj } from '../data.service';
import { Router } from '@angular/router';
import { PasswordChangeDialogComponent } from '../password-change-dialog/password-change-dialog.component';
import { MatDialog } from '@angular/material/dialog';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  data!: LoginObj
  loginError!: string
  loginSuccess!: boolean
  constructor(public dService: DataService, public router: Router, public dialog: MatDialog) { }
  ngOnInit(): void { }
  loginCall(data: LoginObj) {
    debugger
    sessionStorage.setItem('rollNo', data.username)
    this.dService.getData(data).subscribe((response) => {

      console.log(response)
      this.router.navigate(['/display'])
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('hideSudeNave', 'true')
      // this.dialog.open(PasswordChangeDialogComponent, {
      //   width: '500px',
      //   height: '500px'
      // });
    },
      (error) => {
        debugger
        this.loginSuccess = true;
        this.loginError = error.error?.response
        console.log(error.error?.response)
      })

  }

}
