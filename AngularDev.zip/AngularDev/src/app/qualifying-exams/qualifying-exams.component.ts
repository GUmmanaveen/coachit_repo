import { Component } from '@angular/core';

@Component({
  selector: 'app-qualifying-exams',
  templateUrl: './qualifying-exams.component.html',
  styleUrls: ['./qualifying-exams.component.scss']
})
export class QualifyingExamsComponent {

}
