import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QualifyingExamsComponent } from './qualifying-exams.component';

describe('QualifyingExamsComponent', () => {
  let component: QualifyingExamsComponent;
  let fixture: ComponentFixture<QualifyingExamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QualifyingExamsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QualifyingExamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
