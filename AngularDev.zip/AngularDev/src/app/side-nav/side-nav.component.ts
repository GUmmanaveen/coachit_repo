import { Component } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SideNavService } from '../side-nav.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent {

  title = 'MatRegister';
  isLoggedIn: any;
  opened = false;
  constructor(public sideNavService: SideNavService, public router: Router, public bottomSheet: MatBottomSheet, public dialog: MatDialog) {
  }
  openSideNav() {
    this.sideNavService.showSideNav = !this.sideNavService.showSideNav;
  }
  ngOnInit() {
    localStorage.removeItem('isLoggedIn');
  }
  toHome() {
    this.router.navigate(['/home'])
    localStorage.removeItem('isLoggedIn');
    if (this.sideNavService.showSideNav = true) {
      this.sideNavService.showSideNav = false;
    }
    else {
      this.sideNavService.showSideNav = this.sideNavService.showSideNav
    }
  }
  toQualifyingExams() {
    this.router.navigate(['/qualifyingExam'])
  }
  toCirricular(){
    this.router.navigate(['/cirricular'])
  }
  toCoCirricular(){
    this.router.navigate(['/co-cirricular'])
  }
  toCertificatiosn(){
    this.router.navigate(['/certifications'])
  }
  toTrainings(){
    this.router.navigate(['/trainings'])
  }
  toProjects(){
    this.router.navigate(['/projects'])
  }
  today = new Date();
  isLoggedInCall() {
    this.isLoggedIn = localStorage.getItem('isLoggedIn');
    return this.isLoggedIn;
  }
  toHackathons() {
    this.router.navigate(['/hackathons'])
  }
    toInternship() {
    this.router.navigate(['/internship'])
  }
  openPlacement() {
    this.router.navigate(['/display'])
  }
  openHigherEdu() {
    this.router.navigate(['/higherEdu'])
  }
}

