import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegisterComponent } from './register/register.component';
import { DisplayComponent } from './display/display.component';
import { MaterialModule } from './material/material.module';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { PasswordMaskPipe } from './password-mask.pipe';
import { MobileMaskPipe } from './mobile-mask.pipe';
import { EmailMaskPipe } from './email-mask.pipe';
import { PasswordChangeDialogComponent } from './password-change-dialog/password-change-dialog.component';
import { HigherEduComponent } from './higher-edu/higher-edu.component';
import { QualifyingExamsComponent } from './qualifying-exams/qualifying-exams.component';
import { InternshipComponent } from './internship/internship.component';
import { CirricularActivitiesComponent } from './cirricular-activities/cirricular-activities.component';
import { CoCirricularComponent } from './co-cirricular/co-cirricular.component';
import { CertificationsComponent } from './certifications/certifications.component';
import { WorkshopsComponent } from './trainings/workshops/workshops.component';
import { ProjectsComponent } from './projects/projects.component';
import { HackathonsComponent } from './hackathons/hackathons.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { GetAllComponent } from './get-all/get-all.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    DisplayComponent,
    PasswordMaskPipe,
    MobileMaskPipe,
    EmailMaskPipe,
    PasswordChangeDialogComponent,
    HigherEduComponent,
    QualifyingExamsComponent,
    InternshipComponent,
    CirricularActivitiesComponent,
    CoCirricularComponent,
    CertificationsComponent,
    WorkshopsComponent,
    ProjectsComponent,
    HackathonsComponent,
    SideNavComponent,
    GetAllComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
