import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-password-change-dialog',
  templateUrl: './password-change-dialog.component.html',
  styleUrls: ['./password-change-dialog.component.scss']
})
export class PasswordChangeDialogComponent {
  constructor( public dialog:MatDialog,public router:Router){

  }
  close(){
this.dialog.closeAll();
this.router.navigate(['/display'])
  }
}
