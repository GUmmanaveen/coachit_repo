from flask import jsonify
from flask import Flask
from flask import request
from flask import Response
from flask import make_response
from flask import send_from_directory,send_file
from flask_cors import CORS, cross_origin
from io import BytesIO
import mysql.connector
import json
import collections

app = Flask(__name__)
CORS(app, support_credentials=True)

def getSqlConnection():
    connect_db = mysql.connector.connect(user='root', password='root',
                              #host='192.168.1.39',
                              host='localhost',
                              database='LMS_GVL')
    return connect_db
@app.route("/_ping")
def ping():
    return jsonify({'response':'Success'})
    #return "Server is up and running"

@app.route('/login', methods=['POST'])  
def login():  
    print(request.form) 
    print(type(request.form))
    username = request.form['username']  
    password = request.form['password'] 
    print(username) 
    print(password) 
    connect_db = getSqlConnection()
    connect_db1 = connect_db.cursor()
    sql = "SELECT * FROM login_data WHERE Username = %s AND Password = %s"
    intps = (username,password)
    print(intps)
    data = connect_db1.execute(sql,intps)
    myresult = connect_db1.fetchone()
    connect_db1.close()
    if myresult:
        print(myresult[1])
        if password == myresult[1] : 
            print("Default password is not updated")
            return jsonify({'studentRollNumber':username,"passwordUpdateRequired":True})
        else:
            print("Default password is updated")
            return jsonify({'studentRollNumber':username,"passwordUpdateRequired":False})
    else:
        print("No Match")
        response = make_response(jsonify({'response':'invalid username or password'}))
        response.status = 404

@app.route('/update-password', methods=['POST'])  
def updatePassword():  
    print(request.form) 
    print(type(request.form))
    username = request.form['username']  
    password = request.form['password'] 
    print(username) 
    print(password) 
    connect_db = getSqlConnection()
    connect_db1 = connect_db.cursor()
    sql = "SELECT * FROM login_data WHERE Username = %s AND Password = %s"
    intps = (username,password)
    data = connect_db1.execute(sql,intps)
    myresult = connect_db1.fetchone()
    connect_db1.close()
    if myresult:
        print(myresult[1])
        if password == myresult[1] : 
            print("Default password is not updated")
            return jsonify({'studentRollNumber':username,"passwordUpdateRequired":True})
        else:
            print("Default password is updated")
            return jsonify({'studentRollNumber':username,"passwordUpdateRequired":False})
    else:
        print("No Match")
        response = make_response(jsonify({'response':'invalid username or password'}))
        response.status = 404
        return response 

@app.route("/student-data", methods=['GET'])
def studentData():
    connect_db = getSqlConnection()
    connect_db1 = connect_db.cursor()
    data = connect_db1.execute("SELECT * FROM student_data")
    myresult = connect_db1.fetchall()
    connect_db1.close()
    objects_list= []
    for row in myresult:
      d = collections.OrderedDict()
      d['studentRollNumber'] = row[0]
      d['studentName'] = row[1]
      d['branch'] = row[3]
      d['section'] = row[4]
      objects_list.append(d)
#print(json.dumps(objects_list))
    return jsonify(objects_list)
@app.route("/student-data", methods=['POST'])
def createStudentData():
    content_type = request.headers.get('Content-Type')
    if (content_type == 'application/json'):
        json_request = request.get_json()
        #json_data = json.loads(json_request)
        connect_db = getSqlConnection()
        connect_db1 = connect_db.cursor()
        sql = "INSERT INTO student_data (StudentRollNo,StudentName,StudentEmail,Branch,Section) VALUES (%s, %s, %s, %s, %s)"
        for obj in json_request:
            print(obj)
            print(obj['StudentRollNo'])
            records_to_insert = (obj['StudentRollNo'],obj['StudentName'],obj['StudentEmail'],obj['Branch'],obj['Section'])
            connect_db1.execute(sql, records_to_insert)
            connect_db.commit()
        #connect_db1.execute("INSERT INTO student_data VALUES %s", json_request)
        #data = connect_db1.execute("""INSERT INTO student_data VALUES ('1234','Murali','murali@gmail.com','IT','A')""")
        connect_db.close()
        return jsonify({'response':'student information successfully recorded'})
        
    else:
        return 'Content-Type not supported!'
    
@app.route("/student-placement-data", methods=['POST'])
#@cross_origin(support_credentials=True)
def createStudentPlacementData():
    content_type = request.headers.get('Content-Type')
    print(content_type)
    print(request)
    print(request.form)
    requestForm = request.form
    print(request.files)
    if(len(request.files) > 0):
        if("offer-letter" in request.files):
            inputOfferLetterFile = request.files['offer-letter']
            offerLetterData = inputOfferLetterFile.read()
            sql = "INSERT INTO student_placements (StudentRollNo,OfferNumber,Employer,Package,CompanyType,CampusType,offer_letter) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            records_to_insert = ((request.form)['student-roll-number'],
                         (request.form)['offer-number'],
                         (request.form)['company-name'],
                         (request.form)['package'],
                         (request.form)['company-type'],
                         (request.form)['campus-type'],
                        offerLetterData)
        if("letter-of-intent" in request.files):
            inputLetterOfIntent = request.files['letter-of-intent']
            letterOfIntentData = inputLetterOfIntent.read()
            sql = "INSERT INTO student_placements (StudentRollNo,OfferNumber,Employer,Package,CompanyType,CampusType,letter_of_intent) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            records_to_insert = ((request.form)['student-roll-number'],
                         (request.form)['offer-number'],
                         (request.form)['company-name'],
                         (request.form)['package'],
                         (request.form)['company-type'],
                         (request.form)['campus-type'],
                        letterOfIntentData)
    else:
        print("No Files")
        sql = "INSERT INTO student_placements (StudentRollNo,OfferNumber,Employer,Package,CompanyType,CampusType) VALUES (%s, %s, %s, %s, %s, %s)"
        records_to_insert = ((request.form)['student-roll-number'],
                         (request.form)['offer-number'],
                         (request.form)['company-name'],
                         (request.form)['package'],
                         (request.form)['company-type'],
                         (request.form)['campus-type']
      )
    connect_db = getSqlConnection()
    connect_db1 = connect_db.cursor()
    # sql = "INSERT INTO student_placements (StudentRollNo,OfferNumber,Employer,Package,CompanyType,CampusType,offer_letter,letter_of_intent) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    # records_to_insert = ((request.form)['student-roll-number'],
    #                      (request.form)['offer-number'],
    #                      (request.form)['company-name'],
    #                      (request.form)['package'],
    #                      (request.form)['company-type'],
    #                      (request.form)['campus-type'],
    #                     offerLetterData,letterOfIntentData
    #   )
    connect_db1.execute(sql, records_to_insert)
    connect_db.commit()
    connect_db.close()
    response = make_response(jsonify({'response':'student placement information successfully recorded'}))
    return response

@app.route("/student-higher-education-data", methods=['POST'])
#@cross_origin(support_credentials=True)
def createStudentHigherEducationData():
    content_type = request.headers.get('Content-Type')
    print(content_type)
    print(request)
    print(request.form)
    requestForm = request.form
    inputAdmissionLetterFile = request.files['admission-letter']
    admissionLetterData = inputAdmissionLetterFile.read()
    connect_db = getSqlConnection()
    connect_db1 = connect_db.cursor()
    sql = "INSERT INTO student_higher_education (StudentRollNo,Course,University,Country,Specialisation,AdmissionDate,AdmissionLetter) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    records_to_insert = ((request.form)['student-roll-number'],
                         (request.form)['course'],
                         (request.form)['university'],
                         (request.form)['country'],
                         (request.form)['speciialisation'],
                         (request.form)['admission-date'],
                        admissionLetterData
      )
    connect_db1.execute(sql, records_to_insert)
    connect_db.commit()
    connect_db.close()
    response = make_response(jsonify({'response':'student higher education information successfully recorded'}))
    return response
    

@app.route("/student-placement-data", methods=['GET'])
def getStudentPlacementData():
        args = request.args
        package = args.get('package')
        print(package)
        if(package == None):
            print("package empty")
        else:
            print(package)
        connect_db = getSqlConnection()
        connect_db1 = connect_db.cursor()
        sql = "SELECT * FROM student_placements"
        data = connect_db1.execute(sql)
        myresult = connect_db1.fetchall()
        connect_db.close()
        objects_list= []
        for row in myresult:
          d = collections.OrderedDict()
          d['studentRollNumber'] = row[0]
          d['offerNumber'] = row[1]
          d['employer'] = row[2]
          d['package'] = row[3]
          d['companyType'] = row[4]
          d['campusType'] = row[5]
          objects_list.append(d)
        return jsonify(objects_list)

@app.route("/files", methods=['GET'])
def getfiles():
    print((request.args)['letter-type'])
    try:
        connect_db = getSqlConnection()
        connect_db1 = connect_db.cursor()
        sql = "SELECT * FROM student_placements where StudentRollNo= %s"
        studentRollNumber = (request.args)['student-roll-number']
        intParams=(studentRollNumber,)
        print(intParams)
        data = connect_db1.execute(sql,intParams)
        myresult = connect_db1.fetchone()
        connect_db.close()
        if((request.args)['letter-type'] == 'offer-letter'):
            binaryData = myresult[8]
            fileName = studentRollNumber + "_" + myresult[2] + "_" + str(myresult[1]) + "_offer_letter.pdf"
        else:
            binaryData = myresult[9]
            fileName = studentRollNumber + "_" + myresult[2] + "_" + str(myresult[1]) + "_letter_of_intent.pdf"
        #return send_from_directory("D:\Oxygen ITCS\DevWork\LMS_GVL",binaryData , as_attachment=True)
        
        print(fileName)
        return send_file(BytesIO(binaryData),download_name=fileName, as_attachment=True)
    except FileNotFoundError:
        print("Invlid Content Type")
        response = make_response(jsonify({'response': 'File Not Found'}))
        response.status = 404
        return response

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8085, debug = True)